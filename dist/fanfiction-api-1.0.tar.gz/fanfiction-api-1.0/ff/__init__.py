__author__ = 'Samson Danziger'

from fiction import *
from downloader import *
#from authentication import FFLogin
